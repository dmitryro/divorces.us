import wizard from 'gritcode-components/src/components/wizard'
import toast from 'gritcode-components/src/components/toast'

new Vue({ components: { 'vs-toast': toast,'vs-wizard': wizard }})
